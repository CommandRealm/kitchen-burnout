# Player state
scoreboard objectives add has_left minecraft.custom:minecraft.leave_game
scoreboard objectives add held_item dummy
scoreboard objectives add slot dummy
scoreboard objectives add slot_old dummy
scoreboard objectives add click_length dummy
scoreboard objectives add click_length_cooldown dummy

# Readying Up
scoreboard objectives add ready dummy
scoreboard objectives add pregame_click minecraft.used:minecraft.knowledge_book
scoreboard objectives add drop_ready_book minecraft.dropped:minecraft.knowledge_book
scoreboard objectives add pregame dummy

# Number objective
scoreboard objectives add number dummy
scoreboard players set $-1 number -1
scoreboard players set $3 number 3
scoreboard players set $7 number 7
scoreboard players set $20 number 20

# Game state
scoreboard objectives add game dummy
scoreboard objectives add state dummy
scoreboard players add $game state 0
scoreboard objectives add end trigger
scoreboard objectives add restart trigger

scoreboard objectives add prefix dummy

# Settings
scoreboard objectives add settings dummy
scoreboard players set $recipes settings 1
scoreboard players add $mode settings 0
scoreboard players add $map settings 0
execute if score $map settings matches 0 run scoreboard players set $map settings 1

scoreboard objectives add map dummy

scoreboard objectives add click minecraft.used:carrot_on_a_stick
scoreboard objectives add click_cooldown dummy

# Enderchest stuff
scoreboard objectives add open_echest minecraft.custom:minecraft.open_enderchest
scoreboard objectives add click_ec dummy
scoreboard objectives add screen dummy

scoreboard objectives add hat dummy
scoreboard objectives add knife dummy
scoreboard objectives add bell_sound dummy

# Advancement stuff
scoreboard objectives add finished_games dummy
scoreboard objectives add finished_orders dummy
scoreboard objectives add ingredients_taken dummy
scoreboard objectives add ingredients_cut dummy
scoreboard objectives add fish_caught dummy
scoreboard objectives add ingredients_trashed dummy
scoreboard objectives add ingredients_burnt dummy

# Stations
scoreboard objectives add station dummy
scoreboard objectives add station_timer dummy
scoreboard objectives add cutting_inputs_completed dummy
scoreboard objectives add cutting_inputs_length dummy
scoreboard objectives add cutting_id dummy

scoreboard objectives add prep_display dummy
scoreboard objectives add prep_position dummy
scoreboard objectives add prep_id dummy
scoreboard objectives add prep_index dummy

scoreboard objectives add floating_text dummy
scoreboard objectives add fish_count dummy

# Kitchen Specific
scoreboard objectives add tnt_launchpad dummy
scoreboard objectives add warp_fish dummy
scoreboard objectives add arrow_cycle dummy
scoreboard objectives add archery dummy
scoreboard objectives add in_pipe_time dummy
scoreboard objectives add ice_bridge dummy
scoreboard objectives add campfire_heat dummy
scoreboard objectives add thin_ice dummy

scoreboard objectives add sliding_platform dummy
scoreboard objectives add sliding_dir dummy

scoreboard objectives add laser_slide_dir dummy
scoreboard objectives add laser_pos dummy
scoreboard objectives add laser_z dummy

scoreboard objectives add freeze_time dummy
scoreboard objectives add freeze_pos_x dummy
scoreboard objectives add freeze_pos_y dummy
scoreboard objectives add freeze_pos_z dummy
scoreboard objectives add freeze_rot_x dummy
scoreboard objectives add freeze_rot_y dummy

# TODO: Ingredient specific teams

scoreboard objectives add random dummy

# Serving
scoreboard objectives add serving dummy
scoreboard objectives add order_cooldown dummy
scoreboard objectives add order_timer dummy
scoreboard objectives add recipe dummy
scoreboard objectives add sidebar dummy [{translate:"sidebar.header.title",color:"#FFFDEB",font:"kb2:handwritten",underlined:true}]
scoreboard objectives modify sidebar displayautoupdate true

# Recipe Ingredient Teams
team add recipe_missing
team modify recipe_missing color red
team modify recipe_missing collisionRule never

team add recipe_filled
team modify recipe_filled color green
team modify recipe_filled collisionRule never


# Teams
team add lobby
team add unlock
team add test
team add translate
team add help
team add bld
team add prg
team add srbld
team add srprg
team add art
team add srart
team add lead
team add manager
team modify lobby color white
team modify test color white
team modify translate color white
team modify help color white
team modify bld color white
team modify prg color white
team modify srbld color white
team modify srprg color white
team modify art color white
team modify srart color white
team modify lead color white
team modify manager color white
team modify unlock color white
team modify unlock prefix {translate:"[SPORK] ",color:"light_purple"}
team modify test prefix {translate:"(Tester) ",color:"white"}
team modify translate prefix [{translate:"(Translator)",color:"#fc58aa"},{text:" "}]
team modify help prefix {translate:"[Helper] ",color:"gray"}
team modify bld prefix {translate:"{Builder} ",color:"blue"}
team modify prg prefix {translate:"{Programmer} ",color:"red"}
team modify srbld prefix {translate:"{Sr. Builder} ",color:"dark_blue"}
team modify srprg prefix {translate:"{Sr. Programmer} ",color:"dark_red"}
team modify art prefix {translate:"{Artist} ",color:"green"}
team modify srart prefix {translate:"{Sr. Artist} ",color:"dark_green"}
team modify lead prefix [{text:"{",color:"dark_purple",bold:true},{translate:"Project Lead",bold:false},{text:"} ",bold:true}]
team modify manager prefix {translate:"{Manager} ",color:"yellow"}

team add cr
team modify cr color white
team modify cr prefix [{text:"{",color:"white",bold:true},{text:"C",color:"aqua",bold:true},{text:"R",color:"dark_aqua",bold:true},{text:"} ",color:"white",bold:true}]

team modify unlock collisionRule never
team modify lobby collisionRule never
team modify test collisionRule never
team modify translate collisionRule never
team modify help collisionRule never
team modify bld collisionRule never
team modify prg collisionRule never
team modify srbld collisionRule never
team modify srprg collisionRule never
team modify lead collisionRule never
team modify manager collisionRule never
team modify cr collisionRule never
team add no_collision
team modify no_collision collisionRule never
team modify no_collision color gray

# Gamerules
gamerule max_command_sequence_length 20000000
gamerule command_block_output false
gamerule advance_time false
gamerule fire_spread_radius_around_player 0
gamerule spawn_phantoms false
gamerule limited_crafting true
gamerule mob_drops false
gamerule entity_drops false
gamerule spawn_mobs false
gamerule block_drops false
gamerule advance_weather false
gamerule drowning_damage false
gamerule fall_damage false
gamerule fire_damage false
gamerule keep_inventory true
gamerule mob_griefing false
gamerule natural_health_regeneration false
gamerule random_tick_speed 0
gamerule player_movement_check false
# gamerule reducedDebugInfo true
# gamerule sendCommandFeedback false
gamerule show_death_messages false
gamerule spectators_generate_chunks false
gamerule universal_anger false

# Lobby bossbar
bossbar remove minecraft:lobby
#bossbar add minecraft:lobby ["",{text:"\U0001F525 ",color:"red",shadow_color:-13828096}, \
    {translate:"title.kitchen",color:"#FFFDEB",font:"kb2:title",shadow_color:-11777219},{text:" ",font:"kb2:title"}, \
    {translate:"title.burnout",color:"gold",font:"kb2:title",shadow_color:-12311039},{text:" 2",color:"#de4811",font:"kb2:title_2",shadow_color:-13828096}, \
    {text:" emdash ",color:"gray",font:"kb2:ui"},{text:"By the ",color:"white",font:"kb2:ui"}, \
    {text:"Command ",color:"aqua",font:"kb2:ui"},{text:"Realm ",color:"dark_aqua",font:"kb2:ui"}, \
    {text: "Team",color:"white",font:"kb2:ui"},{text:" \U0001F525",color:"red",shadow_color:-13828096}]
bossbar add minecraft:lobby ["",{translate:"title.kitchen",color:"#FFFDEB",font:"kb2:title",shadow_color:-11777219},{text:" ",font:"kb2:title"}, \
    {translate:"title.burnout",color:"gold",font:"kb2:title",shadow_color:-12311039},{text:" 2",color:"#de4811",font:"kb2:title_2",shadow_color:-13828096}, \
    {text:" by ",color:"gray",font:"kb2:title"}, \
    {text:"Command ",color:"aqua",font:"kb2:title"},{text:"Realm ",color:"dark_aqua",font:"kb2:title"}]
bossbar set minecraft:lobby style progress
bossbar set minecraft:lobby color white
bossbar set minecraft:lobby max 1
bossbar set minecraft:lobby value 1
bossbar set minecraft:lobby players @a[tag=in_lobby]
bossbar set minecraft:lobby visible true

title @a times 0 25 5

#data modify storage a a set value 1_000_000l
#data modify entity @n Health set value 0_5.02_5f
#summon armor_stand ~ ~ ~ {Pose:{Head:[0_1.1__1f,0f,0f]},Motion:[1_0.2_3e+02_0d,1.0d,1.0d]}

# TODO: Tutorial setup
#function lobby:tutorial/setup

# Forceload that chunk, I believe in you!
forceload add 0 0