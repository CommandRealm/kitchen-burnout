# Called to create a cutting board
execute align xyz run kill @e[tag=cutting_board,dx=0,dy=0,dz=0]
setblock ~ ~ ~ spruce_pressure_plate[powered=true]

execute align xyz run summon interaction ~0.5 ~ ~0.5 {Tags:["cutting_board","station","reset_between_games","interactable"],width:1.0f,height:0.1f,response:true}
execute align xyz run summon item_display ~0.5 ~0.075 ~0.5 {Tags:["cutting_board","station","reset_between_games"],Rotation:[0f, 90f],item_display:"fixed",brightness:{sky:15,block:15},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],scale:[0.65f,0.65f,0.65f],translation:[0f,0f,0f]}}
# Icon
#summon minecraft:area_effect_cloud ~ ~-.4 ~ {Age: -2147483648, Duration: -1, WaitTime: -2147483648, Tags: ["reset_between_games","station_display_text"],CustomNameVisible:1b,CustomName:'[{"text":"🗡","color":"aqua"}]'}

# Get a unique id
execute align xyz as @n[type=interaction,tag=cutting_board,dx=0,dy=0,dz=0] store result score @s cutting_id run scoreboard players add $new cutting_id 1