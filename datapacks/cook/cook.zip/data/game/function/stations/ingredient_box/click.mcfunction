# Called by an ingredient box that has been clicked on by a player
data modify storage game:stations/box id set from entity @s data.ingredient
data modify storage game:stations/box slot set value "weapon.offhand"
execute on target at @s run function game:inventory/set_player_ingredient with storage game:stations/box