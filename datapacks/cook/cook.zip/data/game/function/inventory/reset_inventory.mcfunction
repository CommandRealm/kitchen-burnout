# Get the selected slot
execute store result score @s slot run data get entity @s SelectedItemSlot
scoreboard players add @s slot 1

# Fill the rest of the hotbar with invisible items for right click detection
#execute unless score @s slot matches 1 run item replace entity @s hotbar.0 with ender_eye[tooltip_display={hide_tooltip:true},item_name="",item_model="minecraft:gray_stained_glass_pane"]
#execute unless score @s slot matches 2 run item replace entity @s hotbar.1 with ender_eye[tooltip_display={hide_tooltip:true},item_name="",item_model="minecraft:gray_stained_glass_pane"]
#execute unless score @s slot matches 3 run item replace entity @s hotbar.2 with ender_eye[tooltip_display={hide_tooltip:true},item_name="",item_model="minecraft:gray_stained_glass_pane"]
#execute unless score @s slot matches 4 run item replace entity @s hotbar.3 with ender_eye[tooltip_display={hide_tooltip:true},item_name="",item_model="minecraft:gray_stained_glass_pane"]
#execute unless score @s slot matches 5 run item replace entity @s hotbar.4 with ender_eye[tooltip_display={hide_tooltip:true},item_name="",item_model="minecraft:gray_stained_glass_pane"]
#execute unless score @s slot matches 6 run item replace entity @s hotbar.5 with ender_eye[tooltip_display={hide_tooltip:true},item_name="",item_model="minecraft:gray_stained_glass_pane"]
#execute unless score @s slot matches 7 run item replace entity @s hotbar.6 with ender_eye[tooltip_display={hide_tooltip:true},item_name="",item_model="minecraft:gray_stained_glass_pane"]
#execute unless score @s slot matches 8 run item replace entity @s hotbar.7 with ender_eye[tooltip_display={hide_tooltip:true},item_name="",item_model="minecraft:gray_stained_glass_pane"]
#execute unless score @s slot matches 9 run item replace entity @s hotbar.8 with ender_eye[tooltip_display={hide_tooltip:true},item_name="",item_model="minecraft:gray_stained_glass_pane"]

# Clear the hotbar
clear @s ender_eye

# Holding a knife
item replace entity @s[tag=!holding_knife,tag=!holding_spatula] weapon.mainhand with air
item replace entity @s[tag=holding_knife] weapon.mainhand with ender_eye[tooltip_display={hide_tooltip:true},item_name={"translate":"tool.knife"},item_model="kb2:tool/knife/default"]
item replace entity @s[tag=holding_spatula] weapon.mainhand with ender_eye[tooltip_display={hide_tooltip:true},item_name={"translate":"tool.spatula"},item_model="kb2:tool/spatula"]

# Changes the player's currently held item to the specified item.
# 0 - Nothing
# 1 - Ingredients with their actual ingredient being saved in the ingredient cache (game:inventory/ingredient)
#execute if score @s held_item matches 0 run item replace entity @s weapon.mainhand with ender_eye[tooltip_display={hide_tooltip:true},item_name="",item_model="minecraft:air"]
#execute if score @s held_item matches -2 run item replace entity @s weapon.mainhand with ender_eye[tooltip_display={hide_tooltip:true},item_name={"translate": "tool.fishing_net"},item_model="minecraft:string"]
#execute if score @s held_item matches -3 run item replace entity @s weapon.mainhand with ender_eye[tooltip_display={hide_tooltip:true},item_name={"translate": "tool.ice_cream_scooper"},item_model="minecraft:iron_shovel"]

execute unless score @s held_item matches 1.. run item replace entity @s weapon.offhand with air
execute unless score @s held_item matches 1.. run return 1
# Get the held ingredient from the ingredient cache
data remove storage game:inventory/held_item {}
data modify storage game:inventory/held_item entity set value "@s"
data modify storage game:inventory/held_item slot set value "weapon.offhand"
function tools:storage/get_for_player {path:"game:inventory/ingredient",result_key:"held_item"}
data modify storage game:inventory/held_item id set from storage game:inventory/ingredient held_item
data remove storage game:inventory/ingredient held_item

function game:inventory/get_ingredient with storage game:inventory/held_item